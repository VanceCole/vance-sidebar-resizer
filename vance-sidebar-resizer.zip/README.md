# Vance's Sidebar Resizer
Allows users to resize the sidebar of Foundry VTT

Simply hover over the edge of the sidebar and a resize cursor should appear, drag to the size you prefer. Will remember the size, individual to the computer you are using.

# Module & System Incompatibilities
Certain modules or systems may be incompatible with this module if they specify an !important flag on the width of the sidebar, in such cases please ping me on discord @vance#1935 and I can look into adding compatibility.